<?php

	$app_name = "The Stream";
	$app_version = "4.2.0";
	$copyright = "Copyright © 2022 Solodroid Developer";
	$menu_dashboard = "Dashboard";
	$menu_category = "Manage Category";
	$menu_channel = "Manage Channel";
	$menu_ads = "Manage Ads";
	$menu_notification = "Notification";
	$menu_administrator = "Administrators";
	$menu_setting = "Settings";
	$menu_app = "Apps";
	$menu_license = "License";
	$menu_logout = "Logout";

?>