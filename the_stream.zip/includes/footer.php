
    <?php include_once ('modals.php'); ?>
    <?php include_once ('assets/js.min.php'); ?>

</body>

</html>